**Step 1)** Fold the paper in half.

**Step 2)** Fold both sides up along the dotted lines.

**Step 3)** Fold both sides down along the dotted lines.

**Step 4)** Fold the top layer of paper down along the dotted line.

**Step 5)** Fold the bottom layer of paper down along the dotted line.

**Step 6)** Fold the top of the paper down along the dotted line.

**Step 7)** Fold both sides out along the dotted lines to make the wings.

**Step 8)** Fold both sides of the paper behind the model.

**Step 9)** Turn the paper over.

**Step 10)** Make 3 Pleat Folds on the bottom of the model.