**Step 1)** Fold and unfold the paper in half both ways.

**Step 2)** Fold both sides in to the center along the dotted lines.

**Step 3)** Fold both sides in to the center along the dotted lines.

**Step 4)** Open up the paper completely.

**Step 5)** Fold the paper over along the dotted line.

**Step 6)** Fold the paper back out over to the left.

**Step 7)** Fold the right side of the paper over along the dotted line and then fold it back out like on the other side.

**Step 8)** Make a small fold on each side along the dotted lines.

**Step 9)** Open up the paper along the dotted lines. Lift it up and push it flat. Look at the next diagram to see the final position of this fold.

**Step 10)** Fold the top of the top layer of paper down along the dotted line.

**Step 11)** Fold both sides in along the dotted lines.

**Step 12)** Fold the top of the paper down along the dotted line.

**Step 13)** Fold the paper underneath along both the dotted lines.

**Step 14)** Make two Pleat Folds to form the ears.

**Step 15)** Fold the paper in half a little bit to make the model a bit 3D.
